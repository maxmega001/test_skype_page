function myFunction(){
    document.getElementById("subprod").classList.toggle("show");
}

function myFunction2(){
    document.getElementById("subprod2").classList.toggle("show");
}

function myFunction3(){
    document.getElementById("sublogin").classList.toggle("show");
}


window.onclick = function(e){
    if(!e.target.matches('.dropprod')){
        var subprod = document.getElementById("subprod");
        if (subprod.classList.contains('show')){
            subprod.classList.remove('show');
        }
    }

    if (!e.target.matches('.dropprod2')){
        var subprod2 = document.getElementById("subprod2");
        if (subprod2.classList.contains('show')){
            subprod2.classList.remove('show');
        }
    }

    if (!e.target.matches('.login')){
        var sublogin = document.getElementById("sublogin");
        if (sublogin.classList.contains('show')){
            sublogin.classList.remove('show');
        }
    }
}




function showFunction(n) {
    var slides = document.getElementsByClassName("mySlides");
    var i;
    for(i=0;i<slides.length;i++){
        slides[i].style.display = "none";
    }
    slides[n].style.display="block";
}



function scrollFunc(k) {
    var scrolls = document.getElementsByClassName("content2");
    if(k==1){
        var p = 0;
        for(var i = 0;i<4;i++){
            if(scrolls[i].style.marginLeft=="-500px"){
                p+=1;
            }
        }
        scrolls[p].style.transition="0.3s linear";
        scrolls[p].style.marginLeft="-500px";
        scrolls[p+1].style.marginLeft="30px";
    }
    if (k==0){
        var p = 0;
        for(var i=0;i<4;i++){
            if(scrolls[i].style.marginLeft=="-500px"){
                p+=1;
            }
        }
        console.log(p);
        scrolls[p-1].style.transition="0.3s linear";
        scrolls[p-1].style.marginLeft="30px";
        scrolls[p].style.marginLeft="30px"
    }
}